/*
** EPITECH PROJECT, 2024
** B-CPP-500-LYN-5-1-rtype-basile.fouquet
** File description:
** PlayerControl.hpp
*/

#pragma once

#include "GEngine/libdev/Component.hpp"

namespace rtype::component {
struct PlayerControl : public gengine::Component<PlayerControl> {
    PlayerControl() {}
};

} // namespace gengine::component
